#ifndef COMMON_H
#define COMMON_H

#define TEAM_SIZE 4
#define NUM_TEAMS 2
#define TOTAL_PLAYERS (TEAM_SIZE * NUM_TEAMS)
#define MAX_ROUNDS 5
#define energy_limit 50
#define Rate_Min 1
#define Rate_Max 5
#define Regained_Max 90
#define Regained_Min 10
#define Recovery_Max 3
#define Recovery_Min 1
#define Max_Energy 100
#define Min_Energy 0
#define Fall_Range 19
#define TimeOut 100000
#define CMD_GET_ENERGY -2
#define ROUND_DURATION 5
#define THRESHOLD 3000
#define CMD_GET_WINNER -3
#define SCORE_THRESHOLD 4
#define CONSECUTIVE_WINS 2
#define SIG_ALIGN SIGUSR1
#define SIG_PULL  SIGUSR2

typedef enum {
    TEAM1 = 0,
    TEAM2 = 1
} Team;

typedef struct {
    int index;
    int energy;
    int position;
} PlayerInfo;

#endif