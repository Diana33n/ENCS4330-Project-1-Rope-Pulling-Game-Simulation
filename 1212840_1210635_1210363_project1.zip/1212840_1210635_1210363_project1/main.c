//Shahd Abdallah 1212840
//Masa Shaheen 1210635
//Diana Muzahem 1210363

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <time.h>
#include <errno.h>
#include <sys/select.h>
#include "common.h"

pid_t players[TOTAL_PLAYERS];
int pipes[TOTAL_PLAYERS][2];
int command_pipes[TOTAL_PLAYERS][2];
int player_energy[TOTAL_PLAYERS];
int score[NUM_TEAMS] = {0};
int consecutive_wins[NUM_TEAMS] = {0};
int last_winner = -1;
int visualizer_pid = -1;
int sorted_order[NUM_TEAMS][TEAM_SIZE];

void create_players() {
    for (int i = 0; i < TOTAL_PLAYERS; i++) {
        if (pipe(pipes[i]) == -1 || pipe(command_pipes[i]) == -1) {
            perror("pipe");
            exit(1);
        }

        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            exit(1);
        } else if (pid == 0) {
            close(pipes[i][0]);
            close(command_pipes[i][1]);
            dup2(pipes[i][1], STDOUT_FILENO);
            dup2(command_pipes[i][0], STDIN_FILENO);
            close(pipes[i][1]);
            close(command_pipes[i][0]);

            char idx[10];
            snprintf(idx, sizeof(idx), "%d", i);
            execl("./rope_game", "rope_game", "player", idx, NULL);
            perror("execl");
            exit(1);
        } else {
            players[i] = pid;
            close(pipes[i][1]);
            close(command_pipes[i][0]);

            if (read(pipes[i][0], &player_energy[i], sizeof(int)) != sizeof(int)) {
                perror("read energy failed");
                exit(1);
            }
        }
    }
}

void sort_and_display_teams(int sorted_order[NUM_TEAMS][TEAM_SIZE]) {
    PlayerInfo team[TEAM_SIZE];
    for (int t = 0; t < NUM_TEAMS; t++) {
        for (int i = 0; i < TEAM_SIZE; i++) {
            int idx = t * TEAM_SIZE + i;
            team[i].index = idx;
            team[i].energy = player_energy[idx];
        }

        for (int i = 0; i < TEAM_SIZE - 1; i++) {
            for (int j = i + 1; j < TEAM_SIZE; j++) {
                if (team[i].energy > team[j].energy) {
                    PlayerInfo tmp = team[i];
                    team[i] = team[j];
                    team[j] = tmp;
                }
            }
        }

        for (int i = 0; i < TEAM_SIZE; i++) {
            sorted_order[t][i] = team[i].index;
        }


        fprintf(stderr, "\n-> Team %d sorted by energy:\n", t);
        for (int i = 0; i < TEAM_SIZE; i++) {
            fprintf(stderr, "   Player %d → Energy: %d, Multiplier: %d\n",
                   team[i].index, team[i].energy, i+1);
        }

        for (int i = 0; i < TEAM_SIZE; i++) {
            int original_idx = team[i].index;
            int multiplier = i + 1;
            if (write(command_pipes[original_idx][1], &multiplier, sizeof(int)) != sizeof(int)) {
                perror("write multiplier failed");
                exit(1);
            }
        }
    }
    fflush(stderr);
}

void prepare_round(int round) {
    printf("\n Round %d\n", round);
    fflush(stdout);

    // Tell all players to report energy
    for (int i = 0; i < TOTAL_PLAYERS; i++) {
        int cmd = -1;
        if (write(command_pipes[i][1], &cmd, sizeof(int)) != sizeof(int)) {
            perror("write round command failed");
            exit(1);
        }
    }

    // Receive updated energies
    for (int i = 0; i < TOTAL_PLAYERS; i++) {
        if (read(pipes[i][0], &player_energy[i], sizeof(int)) != sizeof(int)) {
            perror("read updated energy failed");
            exit(1);
        }
    
        // Force fallen reset on simulation side (only for debugging)
        if (player_energy[i] > 0) {
            printf("[PREPARE] Player %d is recovered (energy = %d)\n", i, player_energy[i]);
        }
    }
    
    // Sort teams and send multipliers
    sort_and_display_teams(sorted_order);

    //  Write SORT_ORDER to file
    FILE *fp = fopen("game_state.txt", "w");
    if (fp) {
        fprintf(fp, "SORT_ORDER");
        for (int t = 0; t < NUM_TEAMS; t++) {
            for (int i = 0; i < TEAM_SIZE; i++) {
                fprintf(fp, " %d", sorted_order[t][i]);
            }
        }
        fprintf(fp, "\n");
        fclose(fp);
    }

    // Give OpenGL time to display sorted alignment
    sleep(1);

    // Wait for players to ACK
    fd_set readfds;
    struct timeval tv;
    for (int i = 0; i < TOTAL_PLAYERS; i++) {
        FD_ZERO(&readfds);
        FD_SET(pipes[i][0], &readfds);
        tv.tv_sec = 2;
        tv.tv_usec = 0;

        int ret = select(pipes[i][0]+1, &readfds, NULL, NULL, &tv);
        if (ret <= 0) {
            fprintf(stderr, "Timeout waiting for player %d\n", i);
            exit(1);
        }

        char ack;
        if (read(pipes[i][0], &ack, 1) != 1 || ack != 'R') {
            perror("invalid ack");
            exit(1);
        }
    }
}


void signal_players(int signo) {
    for (int i = 0; i < TOTAL_PLAYERS; i++) {
        kill(players[i], signo);
    }
}

void write_game_state_to_file(int round, int winner, int team_effort[NUM_TEAMS], int player_effort[TOTAL_PLAYERS]){
    FILE *fp = fopen("game_state.txt", "w");
    if (!fp) {
        perror("fopen game_state.txt failed");
        return;
    }
  

    fprintf(fp, "ROUND %d\n", round);
    fprintf(fp, "WINNER %d\n", winner);
    fprintf(fp, "SCORE %d %d\n", score[TEAM1], score[TEAM2]);

    int effort_winner = (team_effort[TEAM1] > team_effort[TEAM2]) ? TEAM1 :
                        (team_effort[TEAM2] > team_effort[TEAM1]) ? TEAM2 : -1;
    fprintf(fp, "EFFORT %d %d %d\n", team_effort[TEAM1], team_effort[TEAM2], effort_winner);

    for (int i = 0; i < TOTAL_PLAYERS; i++) {
        int fallen = (player_energy[i] <= 0);
        fprintf(fp, "PLAYER %d %d %d %d %d\n", i,
                (i < TEAM_SIZE) ? TEAM1 : TEAM2,
                player_energy[i], fallen, player_effort[i]);
    }
    

    fclose(fp);
    sleep(1);  // Give OpenGL time to read and display the SORT_ORDER before continuing

}

void write_win_message_to_file(int condition_type, int team) {
    FILE *fp = fopen("game_state.txt", "a");
    if (!fp) {
        perror("fopen game_state.txt failed");
        return;
    }

    switch (condition_type) {
        case 0: // Consecutive wins
            fprintf(fp, "WIN_MESSAGE Team %d wins 2 rounds in a row!\n", team + 1);
            break;
        case 1: // Score reached 3
            fprintf(fp, "WIN_MESSAGE Team %d reaches 3 wins!\n", team + 1);
            break;
        case 2: // Max rounds
            fprintf(fp, "WIN_MESSAGE Max rounds reached! Final scores - Team 1: %d, Team 2: %d\n",
                   score[TEAM1], score[TEAM2]);
            break;
    }
    fclose(fp);
}

int simulate_pull_round(int current_round) {
    int team_effort[NUM_TEAMS] = {0};
    int player_effort[TOTAL_PLAYERS] = {0};
    if (current_round==1){
        write_game_state_to_file(current_round , -1, team_effort, player_effort);
        }
    for (int sec = 0; sec < ROUND_DURATION; sec++) {
     
       
        printf("Referee: PULL! (second %d)\n", sec + 1);
        signal_players(SIG_PULL);

        printf("Effort summary at second %d:\n", sec + 1);
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            int effort = 0;
            if (read(pipes[i][0], &effort, sizeof(int)) == sizeof(int)) {
                Team team = (i < TEAM_SIZE) ? TEAM1 : TEAM2;
                team_effort[team] += effort;
                player_effort[i] = effort;

                printf(" Player %d [Team %d] → Effort: %d\n", i, team + 1, effort);
            }
        }

        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            int cmd = CMD_GET_ENERGY;
            if (write(command_pipes[i][1], &cmd, sizeof(int)) != sizeof(int)) {
                perror("write failed ");
                exit(1);
            }
        }

        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            int energy;
            if (read(pipes[i][0], &energy, sizeof(int)) == sizeof(int)) {
                fprintf(stderr, "Energy Check - Player %d: %d\n", i, energy);
                player_energy[i] = energy;
            }
        }

        write_game_state_to_file(current_round , -1, team_effort, player_effort);
        sleep(1);
        }

    printf("Team 1 effort: %d | Team 2 effort: %d\n", team_effort[TEAM1], team_effort[TEAM2]);

    if (team_effort[TEAM1] > THRESHOLD && team_effort[TEAM2] < THRESHOLD) {
        write_game_state_to_file(current_round , TEAM1, team_effort, player_effort);
                sleep(1);
        return TEAM1;
    }
    if (team_effort[TEAM2] > THRESHOLD && team_effort[TEAM1] < THRESHOLD) {
        write_game_state_to_file(current_round , TEAM2, team_effort, player_effort);
                sleep(1);
        return TEAM2;
    }
    if (team_effort[TEAM1] > team_effort[TEAM2]) {
        write_game_state_to_file(current_round , TEAM1, team_effort, player_effort);
                sleep(1);
        return TEAM1;
    }
    else if (team_effort[TEAM2] > team_effort[TEAM1]) {
        write_game_state_to_file(current_round , TEAM2, team_effort, player_effort);
                sleep(1);
        return TEAM2;
    }
    else {
        write_game_state_to_file(current_round , -1, team_effort, player_effort);
                sleep(1);
        return -1;
    }
}

int check_win_condition(int round, int max_rounds) {
    for (int i = 0; i < NUM_TEAMS; i++) {
        if (consecutive_wins[i] >= CONSECUTIVE_WINS) {
            printf(" Team %d wins 2 rounds in a row!\n", i + 1);
            write_win_message_to_file(0, i);
            return 1;
        }
        if (score[i] >= SCORE_THRESHOLD) {
            printf(" Team %d reaches 4 wins!\n", i + 1);
            write_win_message_to_file(1, i);
            return 1;
        }
    }
    if (round >= max_rounds) {
        printf(" Max rounds reached! Final scores - Team 1: %d, Team 2: %d\n",
               score[TEAM1], score[TEAM2]);
        write_win_message_to_file(2, -1);
        return 1;
    }
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc > 1 && strcmp(argv[1], "player") == 0) {
        extern void player_process(int);
        player_process(atoi(argv[2]));
        exit(0);
    }
    visualizer_pid = fork();
    if (visualizer_pid == -1) {
        perror("fork for visualizer failed");
        exit(1);
    }  else if (visualizer_pid == 0) {
        fprintf(stderr, "Launching visualizer...\n");
        execl("./visualizer", "visualizer", NULL);
        perror("execl visualizer failed");
        exit(1);
    }

    // Parent continues as referee
   

    srand(time(NULL));
    printf("Rope pulling simulation starting...\n");
    fflush(stdout);

    create_players();

    for (int round = 1; round <= MAX_ROUNDS; round++) {
        prepare_round(round);
        int winner = simulate_pull_round(round);

        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            int cmd = CMD_GET_WINNER;
           if( write(command_pipes[i][1], &cmd, sizeof(int)) != sizeof(int))
           {
            perror("write failed");
            exit(1);
           }
        }

        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            if(write(command_pipes[i][1], &winner, sizeof(int)) != sizeof(int))
                  {
                    perror("write failed");
                    exit(1);
                   }
            
        }

        if (winner == TEAM1 || winner == TEAM2) {
            printf(" Team %d wins the round!\n", winner + 1);
            score[winner]++;
            if (last_winner == winner)
                consecutive_wins[winner]++;
            else {
                consecutive_wins[0] = 0;
                consecutive_wins[1] = 0;
                consecutive_wins[winner] = 1;
            }
            last_winner = winner;
        } else {
            printf(" It's a tie!\n");
            consecutive_wins[0] = 0;
            consecutive_wins[1] = 0;
            last_winner = -1;
        }

        if (check_win_condition(round, MAX_ROUNDS)) break;
    }

    printf("\n Game Over. Cleaning up players.\n");
    for (int i = 0; i < TOTAL_PLAYERS; i++) {
        kill(players[i], SIGKILL);
        waitpid(players[i], NULL, 0);
        close(pipes[i][0]);
        close(command_pipes[i][1]);
    }
       // Write final score to file
       FILE *fp = fopen("game_state.txt", "a");
       if (fp) {
           fprintf(fp, "FINAL_SCORE %d %d\n", score[TEAM1], score[TEAM2]);
           fclose(fp);
       }
    sleep(6);   
    if (visualizer_pid > 0) {
        kill(visualizer_pid, SIGKILL);  // or SIGTERM for gentle shutdown
        waitpid(visualizer_pid, NULL, 0);
    }

 
    
    printf("The Final Score → Team 1: %d | Team 2: %d\n", score[TEAM1], score[TEAM2]);
    return 0;
}