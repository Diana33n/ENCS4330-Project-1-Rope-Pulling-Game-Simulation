#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include "common.h"

static int my_index, my_energy, my_rate, my_multiplier;
static Team my_team;
static int my_number;
static volatile sig_atomic_t got_signal = 0;

void handle_pull(int signo) {
    got_signal = SIG_PULL;
}

void player_process(int index) {
    my_index = index;
    my_team = (index < TEAM_SIZE) ? TEAM1 : TEAM2;
    my_number = index % TEAM_SIZE;

    srand(getpid() + time(NULL));
    my_energy = rand() % energy_limit + energy_limit;
    my_rate = rand() % Rate_Max + Rate_Min;

    struct sigaction sa;
    sa.sa_handler = handle_pull;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    if (sigaction(SIG_PULL, &sa, NULL) == -1) {
        perror("sigaction pull failed");
        exit(1);
    }

    if (write(STDOUT_FILENO, &my_energy, sizeof(int)) != sizeof(int)) {
        perror("write energy failed");
        exit(1);
    }

    fprintf(stderr, "[Player %d - Team %d] Ready. Energy=%d, Rate=%d\n",
           my_number, my_team, my_energy, my_rate);
    fflush(stderr);

    while (1) {
        int command;
        ssize_t n;

        fd_set readfds;
        struct timeval tv;
        FD_ZERO(&readfds);
        FD_SET(STDIN_FILENO, &readfds);
        tv.tv_sec = 0;
        tv.tv_usec = TimeOut;

        int ret = select(STDIN_FILENO+1, &readfds, NULL, NULL, &tv);
        if (ret > 0) {
            n = read(STDIN_FILENO, &command, sizeof(int));
            if (n == sizeof(int)) {
                if (command == -1) {


                    if (my_energy==0){
                        my_energy = rand() % energy_limit + energy_limit;

                    }
                    if (write(STDOUT_FILENO, &my_energy, sizeof(int)) != sizeof(int)) {
                        perror("write energy failed");
                        exit(1);
                    }

                    if (read(STDIN_FILENO, &my_multiplier, sizeof(int)) != sizeof(int)) {
                        perror("read multiplier failed");
                        exit(1);
                    }

                    char ack = 'R';
                    if (write(STDOUT_FILENO, &ack, 1) != 1) {
                        perror("write ready failed");
                        exit(1);
                    }

                    fprintf(stderr, "[Player %d - Team %d] Round started. Energy=%d, Multiplier=%d\n",
                           my_number, my_team, my_energy, my_multiplier);
                    fflush(stderr);
                } else if (command == -2) {
                    if (write(STDOUT_FILENO, &my_energy, sizeof(int)) != sizeof(int)) {
                        perror("write current energy failed");
                        exit(1);
                    }
                }
                else if (command == -3) {
                    int winner;
                    if (read(STDIN_FILENO, &winner, sizeof(int)) != sizeof(int)) {
                        perror("read winner failed");
                        exit(1);
                    }
                
                    fprintf(stderr, "[Player %d] Received winner info: Team %d\n", my_number, winner+1);
                    fflush(stderr);
                }
            } else if (n < 0 && errno != EINTR) {
                perror("read command failed");
                exit(1);
            }
        }

        if (got_signal) {
            int signo = got_signal;
            got_signal = 0;

            if (signo == SIG_PULL) {
                int fall = rand() % Fall_Range;
                int effort = 0;
                if (fall == 0) {
                    my_energy=0;

                    fprintf(stderr, "[Player %d - Team %d] Fell! No effort.\n", my_number, my_team);
                    fflush(stderr);
                    int recovery = rand() % Recovery_Max + Recovery_Min;
                    fprintf(stderr, "Recovery Time: %d\n", recovery);
                    sleep(recovery);
                   //sleep(10);
                    
                    if (my_energy > Max_Energy) my_energy = Max_Energy;
                    fprintf(stderr, "[Player %d - Team %d] Recovered. Energy: %d\n",
                           my_number, my_team, my_energy);
                    fflush(stderr);
                } else {
                    if(my_energy==0){
                        my_energy = rand() % energy_limit + energy_limit;
                    }
                    effort = my_energy * my_multiplier;
                    fprintf(stderr, "[Player %d - Team %d] Pulling! Energy: %d × %d = %d\n",
                            my_number, my_team, my_energy, my_multiplier, effort);
                    fflush(stderr);
                    my_energy -= my_rate;
                    if (my_energy < Min_Energy) my_energy = Min_Energy;
                }

                if (write(STDOUT_FILENO, &effort, sizeof(int)) != sizeof(int)) {
                    perror("write effort failed");
                    exit(1);
                }
            }
        }
    }
}
