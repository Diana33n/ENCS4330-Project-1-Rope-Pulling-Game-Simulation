#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "common.h"

#define PLAYER_RADIUS 0.05f
#define ROPE_LENGTH 0.4f
#define BLINK_SPEED 0.2f
#define ROPE_MOVEMENT_SPEED 0.05f
#define SCORE_BOUNCE_SPEED 0.1f
#define ROUND_END_FLASH_DURATION 2.0f
float round_winner_display_duration = 3.0f; // Show for 3 seconds
typedef struct {
    float x, y;
    float target_x;
    int energy;
    int team;
    int fallen;
    int effort;
    float blink_timer;
} Player;

Player players[TOTAL_PLAYERS];
int team1_order[TEAM_SIZE] = {0,1,2,3};
int team2_order[TEAM_SIZE] = {4,5,6,7};

int round_num = 0;
int round_winner = -1;
int team_score[2] = {0, 0};
int team_effort[2] = {0, 0};
float score_bounce_timer = 0.0f;
float flash_timer = 0.0f;
int game_winner = -1;
float rope_position = 0.0f;
int last_round_winner = -1;
float winner_display_timer = 0.0f;
float round_winner_display_timer = 0.0f;
float round_end_flash_timer = 0.0f;
char win_message[256] = {0};
float win_message_timer = 0.0f;

void drawText(float x, float y, const char* text, void* font) {
    glRasterPos2f(x, y);
    while (*text) {
        glutBitmapCharacter(font, *text++);
    }
}

void drawCircle(float x, float y, float r, float red, float green, float blue) {
    glColor3f(red, green, blue);
    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i++) {
        float angle = i * 3.14159f / 180;
        glVertex2f(x + cos(angle) * r, y + sin(angle) * r);
    }
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3f(0.96f, 0.91f, 0.76f);
    glRectf(-1.0f, -1.0f, 1.0f, 1.0f);

    if (round_end_flash_timer > 0 && round_end_flash_timer < ROUND_END_FLASH_DURATION) {
        if (last_round_winner == 0) {
            glColor3f(0.0f, 0.7f, 0.0f);
            glRectf(-1.0f, -1.0f, 0.0f, 1.0f);
            glColor3f(0.7f, 0.0f, 0.0f);
            glRectf(0.0f, -1.0f, 1.0f, 1.0f);
        } else if (last_round_winner == 1) {
            glColor3f(0.7f, 0.0f, 0.0f);
            glRectf(-1.0f, -1.0f, 0.0f, 1.0f);
            glColor3f(0.0f, 0.7f, 0.0f);
            glRectf(0.0f, -1.0f, 1.0f, 1.0f);
        }
    }

    if (game_winner != -1) {
    if (game_winner == 0) {
        // Yellow team - keep original yellow
        glColor3f(0.9f, 0.9f, 0.2f);
    } else {
        // Blue team - medium blue between baby blue and standard blue
        glColor3f(0.3f, 0.5f, 0.9f);  // RGB: 30% red, 50% green, 90% blue
    }
    glRectf(-1.0f, -1.0f, 1.0f, 1.0f);
}

    glColor3f(0.5f, 0.3f, 0.1f);
    glLineWidth(8.0f);
    glBegin(GL_LINES);
    glVertex2f(rope_position - ROPE_LENGTH/2, 0.0f);
    glVertex2f(rope_position + ROPE_LENGTH/2, 0.0f);
    glEnd();

    for (int i = 0; i < TOTAL_PLAYERS; i++) {
        Player* p = &players[i];

        //  Draw player circle
        if (p->fallen) {
            int blink_on = ((int)(p->blink_timer * 10) % 2 == 0);
            if (blink_on) {
                drawCircle(p->x, p->y, PLAYER_RADIUS, 0.3f, 0.3f, 0.3f);  // Gray blinking
            }
        } else if (p->effort == 0) {
            drawCircle(p->x, p->y, PLAYER_RADIUS, 0.5f, 0.5f, 0.5f);  // Gray (no effort)
        } else {
            if (p->team == 0) {
                drawCircle(p->x, p->y, PLAYER_RADIUS, 1.0f, 1.0f, 0.0f);  // Yellow team
            } else {
                drawCircle(p->x, p->y, PLAYER_RADIUS, 0.2f, 0.4f, 1.0f);  // Blue team
            }
        }
        
        //  Always draw energy text above player
        char energy_txt[10];
        sprintf(energy_txt, "%d", p->energy);
        glColor3f(0, 0, 0);
        drawText(p->x - 0.02f, p->y + PLAYER_RADIUS + 0.07f, energy_txt, GLUT_BITMAP_HELVETICA_12);
        
        //  Always draw energy bar above player
        float energy_ratio = (float)p->energy / 100.0f;
        glColor3f(1.0f - energy_ratio, energy_ratio, 0.0f);
        glBegin(GL_QUADS);
        glVertex2f(p->x - PLAYER_RADIUS, p->y + PLAYER_RADIUS + 0.05f);
        glVertex2f(p->x + PLAYER_RADIUS, p->y + PLAYER_RADIUS + 0.05f);
        glVertex2f(p->x + PLAYER_RADIUS, p->y + PLAYER_RADIUS + 0.02f);
        glVertex2f(p->x - PLAYER_RADIUS, p->y + PLAYER_RADIUS + 0.02f);
        glEnd();
        
        //  Always draw effort text below player
        char effort_txt[10];
        sprintf(effort_txt, "%d", p->effort);
        glColor3f(0, 0, 0);
        drawText(p->x - 0.02f, p->y - 0.15f, effort_txt, GLUT_BITMAP_HELVETICA_12);
        
    }

    float bounce = 0.05f * sin(score_bounce_timer);
    glColor3f(0, 0, 0);
    char round_info[50];
    sprintf(round_info, "Round %d", round_num);
    drawText(-0.1f, 0.9f, round_info, GLUT_BITMAP_HELVETICA_18);

    glPushMatrix();
    glTranslatef(0, bounce, 0);
    char score_text[100];
    sprintf(score_text, "Team Yellow: %d (%d)  vs  Team Blue: %d (%d)",
            team_score[0], team_effort[0], team_score[1], team_effort[1]);
    drawText(-0.4f, 0.8f, score_text, GLUT_BITMAP_HELVETICA_18);
    glPopMatrix();

    if (last_round_winner != -1 && round_winner_display_timer < round_winner_display_duration) {
        glColor3f(1.0f, 1.0f, 1.0f);
        char round_result[100];
        sprintf(round_result, "Round %d Winner: Team %s!", 
                round_num, last_round_winner == 0 ? "YELLOW" : "BLUE");
        drawText(-0.3f, -0.8f, round_result, GLUT_BITMAP_HELVETICA_18);
    }

    if (win_message_timer > 0) {
        glColor3f(1.0f, 1.0f, 1.0f);
        drawText(-0.29f, 0.5f, win_message, GLUT_BITMAP_HELVETICA_18);
    }

    if (game_winner != -1 && (int)(winner_display_timer*2)%2==0) {
        glColor3f(1.0f, 1.0f, 1.0f);
        char winner_msg[100];
        sprintf(winner_msg, "GAME OVER! Team %s WINS!",
                game_winner == 0 ? "YELLOW" : "BLUE");
        drawText(-0.3f, 0.7f, winner_msg, GLUT_BITMAP_HELVETICA_18);

        char final_score[100];
        sprintf(final_score, "Final Score: %d - %d", team_score[0], team_score[1]);
        drawText(-0.2f, 0.6f, final_score, GLUT_BITMAP_HELVETICA_18);
    }

    glutSwapBuffers();
}

void loadGameState() {
    FILE* fp = fopen("game_state.txt", "r");
    if (!fp) {
        perror("Error opening game_state.txt");
        return;
    }

     char line[256];
    while (fgets(line, sizeof(line), fp) != NULL) {
        if (strncmp(line, "SORT_ORDER", 10) == 0) {
            printf("Visualizer loaded new SORT_ORDER\n");

            sscanf(line, "SORT_ORDER %d %d %d %d %d %d %d %d",
                   &team1_order[0], &team1_order[1], &team1_order[2], &team1_order[3],
                   &team2_order[0], &team2_order[1], &team2_order[2], &team2_order[3]);
        }
        else if (strncmp(line, "ROUND", 5) == 0) {
            sscanf(line, "ROUND %d", &round_num);
            round_end_flash_timer = 0.0f; // Reset flash timer at start of new round
        }
        else if (strncmp(line, "WINNER", 6) == 0) {
            int winner;
            sscanf(line, "WINNER %d", &winner);
            if (winner != -1) {
                last_round_winner = winner;
                round_winner_display_timer = 0.0f; // Reset timer
                round_end_flash_timer = 0.1f;
                if (team_score[0] >= 3 || team_score[1] >= 3) {
                    game_winner = winner;
                }
            }
        }else if (strncmp(line, "SCORE", 5) == 0) {
            sscanf(line, "SCORE %d %d", &team_score[0], &team_score[1]);
            if (team_score[0] >= SCORE_THRESHOLD) {
                game_winner = 0;
                last_round_winner = 0;
            } else if (team_score[1] >= SCORE_THRESHOLD) {
                game_winner = 1;
                last_round_winner = 1;
            }
        } else if (strncmp(line, "EFFORT", 6) == 0) {
            int effort_winner;
            sscanf(line, "EFFORT %d %d %d", &team_effort[0], &team_effort[1], &effort_winner);
        }else if (strncmp(line, "PLAYER", 6) == 0) {
            int id, team, energy, fallen, effort;
            sscanf(line, "PLAYER %d %d %d %d %d", &id, &team, &energy, &fallen, &effort);
        
            //  FORCE RECOVERY if energy > 0
            if (energy > 0) {
                fallen = 0;
            }
        
            players[id].energy = energy;
            players[id].team = team;
            players[id].effort = effort;
        
            if (fallen) {
                players[id].fallen = 1;
                players[id].blink_timer += BLINK_SPEED;
            } else {
                players[id].fallen = 0;
                players[id].blink_timer = 0.0f;
            }
        }
        
        else if (strncmp(line, "WIN_MESSAGE", 11) == 0) {
            strncpy(win_message, line + 12, sizeof(win_message));
            win_message[strcspn(win_message, "\n")] = 0;
            win_message_timer = 5.0f;
        } else if (strncmp(line, "FINAL_SCORE", 11) == 0) {
            sscanf(line, "FINAL_SCORE %d %d", &team_score[0], &team_score[1]);
            if (team_score[0] > team_score[1]) {
                game_winner = 0;
            } else if (team_score[1] > team_score[0]) {
                game_winner = 1;
            }
        }
    }
    fclose(fp);
}

void timer(int v) {
    loadGameState();
    if (last_round_winner != -1) {
        round_winner_display_timer += 0.1f;
    }

    if (round_end_flash_timer > 0 && round_end_flash_timer < ROUND_END_FLASH_DURATION) {
        round_end_flash_timer += 0.1f;
    }

    if (win_message_timer > 0) {
        win_message_timer -= 0.1f;
    }

float base_rope_center = 0.0f;
float spacing = 0.15f;
float team_offset = 0.2f;

// Team 1 (left side)
for (int i = 0; i < TEAM_SIZE; i++) {
    int player_idx = team1_order[i];
    float relative_pos = -ROPE_LENGTH/2 - team_offset - i * spacing;
    players[player_idx].target_x = base_rope_center + rope_position + relative_pos;
}

// Team 2 (right side)
for (int i = 0; i < TEAM_SIZE; i++) {
    int player_idx = team2_order[i];
    float relative_pos = ROPE_LENGTH/2 + team_offset + i * spacing;
    players[player_idx].target_x = base_rope_center + rope_position + relative_pos;
}

    

 for (int i = 0; i < TOTAL_PLAYERS; i++) {
        if (players[i].fallen) {
            players[i].y = -0.2f;
            players[i].blink_timer += BLINK_SPEED;
        } else {
            players[i].y = 0.0f;
        }

        players[i].x += (players[i].target_x - players[i].x) * 0.1f;
    }

    float target_rope_pos = 0.0f;
    if (team_effort[0] + team_effort[1] > 0) {
       float effort_diff = team_effort[1] - team_effort[0];
        float max_effort = (team_effort[0] + team_effort[1]) / 2.0f;
        target_rope_pos = 0.5f * (effort_diff / max_effort);
    }
    rope_position += (target_rope_pos - rope_position) * ROPE_MOVEMENT_SPEED;

    score_bounce_timer += SCORE_BOUNCE_SPEED;
    flash_timer += 0.1f;
    winner_display_timer += 0.1f;
    round_winner_display_timer += 0.1f;

    glutPostRedisplay();
    glutTimerFunc(50, timer, 0);
}

void init() {
    for (int i = 0; i < TOTAL_PLAYERS; i++) {
        players[i].x = 0;
        players[i].y = 0.0f;
        players[i].energy = 50;
        players[i].team = (i < TEAM_SIZE) ? 0 : 1;
        players[i].fallen = 0;
        players[i].effort = 0;
        players[i].blink_timer = 0;
    }

    flash_timer = 0.0f;
    round_winner = -1;
    game_winner = -1;
    last_round_winner = -1;
    rope_position = 0.0f;
    team_effort[0] = team_effort[1] = 0;
    round_winner_display_timer = 0.0f;
    round_end_flash_timer = 0.0f;
    win_message_timer = 0.0f;

    glClearColor(0.96f, 0.91f, 0.76f, 1.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1, 1, -1, 1);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(1000, 600);
    glutCreateWindow("Rope Pulling Visualizer");

    init();
    glutDisplayFunc(display);
    glutTimerFunc(200, timer, 0);
    glutMainLoop();
    return 0;
}
